/**
 * Created by anushka on 27/2/19.
 */
public class Apple extends Fruit {

    String taste="Sweet";
    String name="Apple";
    public void eat(){
        System.out.println(name +" is "+ taste);
    }
}
