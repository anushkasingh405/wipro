/**
 * Created by anushka on 27/2/19.
 */
public class Fruit {
    String taste="sweet or sour";
    int size;
    String name="Fruit";

    public Fruit(){}
    public Fruit(String taste, int size, String name) {
        this.taste = taste;
        this.size = size;
        this.name = name;
    }

    public void eat(){
        System.out.println(name +" can be "+ taste);
    }
}
