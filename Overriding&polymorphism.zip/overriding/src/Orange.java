/**
 * Created by anushka on 27/2/19.
 */
public class Orange extends Fruit {

    String taste="tangy";
    String name="Orange";
    public void eat(){
        System.out.println(name +" is "+ taste);
    }
}
