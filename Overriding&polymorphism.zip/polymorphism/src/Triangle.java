/**
 * Created by anushka on 27/2/19.
 */
public class Triangle extends Shape {

    public void draw(){
        System.out.println("Drawing Triangle");
    }

    public void erase(){
        System.out.println("Eraseing Triangle");
    }
}
