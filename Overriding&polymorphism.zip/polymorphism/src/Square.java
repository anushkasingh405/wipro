/**
 * Created by anushka on 27/2/19.
 */
public class Square extends  Shape {



        public void draw(){
            System.out.println("Drawing Square");
        }

        public void erase(){
            System.out.println("Eraseing Square");
        }
    }


