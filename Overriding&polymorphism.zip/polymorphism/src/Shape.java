/**
 * Created by anushka on 27/2/19.
 */
public class Shape {

    Shape(){}
    public void draw(){
        System.out.println("Drawing shape");
    }

    public void erase(){
        System.out.println("Eraseing shape");
    }
}
