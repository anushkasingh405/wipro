/**
 * Created by anushka on 27/2/19.
 */
public class Main {

    public static void main(String[] args) {
        Shape s=new Shape();
        s.draw(); s.erase();
        Shape c=new Circle();
        c.draw(); c.erase();
        Shape r=new Square();
        r.draw(); r.erase();
        Shape t=new Triangle();
        t.draw(); t.erase();
    }
}
