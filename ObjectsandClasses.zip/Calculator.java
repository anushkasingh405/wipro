public class Calculator
{
	public static Double powerInt(int m1,int m2)
	{
		Double result=Math.pow(m1,m2);
		return result;
	}
	public static Double powerDouble(Double m1,int m2)
	{
		Double result=Math.pow(m1,m2);
		return result;
	}
	public static void main(String args[])
	{
		    try {
      			  Float.parseFloat(args[0]);
				Double result2=powerDouble(Double.parseDouble(args[0]),Integer.parseInt(args[1]));
				System.out.println(result2);

    			} 
		   catch (NumberFormatException e) {
		
        			Double result=powerInt(Integer.parseInt(args[0]),Integer.parseInt(args[1]));
				System.out.println(result);}

	}
}
