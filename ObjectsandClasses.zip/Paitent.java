public class Paitent
{
   String paitentname;
   Double weight;
   Double height;
   public Paitent(String paitentname,Double weight,Double height)
	{
		this.paitentname=paitentname;
		this.weight=weight;
		this.height=height;
                Double BMI=computeBMI();
		System.out.println(BMI);
	}
//constructors cannot return and computebmi is non static method hence can't be called from main function
	public Double computeBMI()
	{
		Double result=weight/(height*height);
		return result;
	}

    public static void main(String args[])
	{
	    Paitent p= new Paitent(args[0],Double.parseDouble(args[1]),Double.parseDouble(args[2]));
	
	}
}
