

/**
 * Created by anushka on 27/2/19.
 */
public class Person {

    String name;
    String dateOfBirth;

    public Person(String name, String dateOfBirth) {
        this.name = name;
        this.dateOfBirth = dateOfBirth;
    }
}
