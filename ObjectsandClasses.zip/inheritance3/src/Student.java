import java.util.Date;

/**
 * Created by anushka on 27/2/19.
 */
public class Student extends Person {

    String name;
    String studentID;
    String dateOfBirth;

    public Student(String name, String dateOfBirth, String studentID) {
        super(name, dateOfBirth);
        this.name = name;
        this.studentID = studentID;
        this.dateOfBirth = dateOfBirth;
    }

}
