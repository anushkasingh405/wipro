import java.util.Date;

/**
 * Created by anushka on 27/2/19.
 */
public class Teacher extends Person {

    String name;
    int salary;
    String subject;
    String dateOfBirth;

    public Teacher(String name, String dateOfBirth, int salary, String subject) {
        super(name, dateOfBirth);
        this.name = name;
        this.salary = salary;
        this.subject = subject;
        this.dateOfBirth = dateOfBirth;
    }
}
