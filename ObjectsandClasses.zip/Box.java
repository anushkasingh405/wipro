public class Box
{int height; 
 int width;
 int depth;
 
   public Box(int h,int w,int d)
   {
      this.height=h;
	this.width=w;
	this.depth=d;
      int result= Box();  
     System.out.println(result);
}

   public int Box()
	{
		int volume=height*width*depth;
		return volume;
	}


    public static void main(String args[])
	{
	    Box result= new Box(Integer.parseInt(args[0]),Integer.parseInt(args[1]),Integer.parseInt(args[2]));
	
	}
}
