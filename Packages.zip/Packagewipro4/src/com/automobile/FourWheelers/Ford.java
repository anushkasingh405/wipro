package com.automobile.FourWheelers;

import com.automobile.Vehicle;

/**
 * Created by anushka on 15/3/19.
 */
public class Ford extends Vehicle{

    String Modelname ="FORD SUV";
    String  registrationnumber="XY21";
    String Ownername="anu singh";
    int speed=180;
    int tempControl=18;
    public String getModelname() { return Modelname;}

    public String getRegistrationnumber(){return registrationnumber;}

    public String getOwnername(){return Ownername;}
    public int Speed(){return speed;}
    public int tempControl(){return tempControl;}
}
