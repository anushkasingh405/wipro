package com.automobile.FourWheelers;

import com.automobile.Vehicle;

/**
 * Created by anushka on 15/3/19.
 */
public class Logan extends Vehicle {

    String Modelname ="Logan200R";
    String  registrationnumber="TR4321";
    String Ownername="shashank verma";
    int speed=120;
    int gps=28;
    public String getModelname() {Modelname=Modelname; return Modelname;}

    public String getRegistrationnumber(){return registrationnumber;}

    public String getOwnername(){return Ownername;}
    public int Speed(){return speed;}
    public int gps(){return gps;}

}
