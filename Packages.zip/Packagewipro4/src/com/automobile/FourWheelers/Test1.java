package com.automobile.FourWheelers;

/**
 * Created by anushka on 15/3/19.
 */
public class Test1 {
    public static void main(String[] args) {

        Ford ford=new Ford();
        Logan logan=new Logan();
        System.out.println(ford.getModelname());
        System.out.println(ford.getOwnername());
        System.out.println(ford.getRegistrationnumber());
        System.out.println(ford.Speed());
        ford.tempControl();
        System.out.println(logan.getModelname());
        System.out.println(logan.getOwnername());
        System.out.println(logan.getRegistrationnumber());
        System.out.println(logan.Speed());
        logan.gps();

    }
}
