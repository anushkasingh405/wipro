package com.automobile;

/**
 * Created by anushka on 15/3/19.
 */
public abstract class Vehicle {
    String Modelname;
    String  registrationnumber;
    String Ownername;

    public abstract String getModelname();

    public abstract String getRegistrationnumber();

    public abstract String getOwnername();


}