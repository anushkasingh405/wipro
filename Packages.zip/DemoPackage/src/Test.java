import TestPackage.Foundation;

public class Test extends Foundation {
    public static void main(String[] args) {

        //getter seetter for private variables
        Foundation foundation=new Foundation();
        foundation.setVar1(1);
        System.out.println(foundation.getVar1());

        //inheritance for protected variables
        Test foundationt=new Test();
        foundationt.var3=3;
        System.out.println(foundationt.var3);

        //default is not accessible

        //public variable
        foundation.var4 =4;
        System.out.println(foundation.var4);

    }
}