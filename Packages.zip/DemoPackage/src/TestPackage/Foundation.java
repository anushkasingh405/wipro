package TestPackage;

/**
 * Created by anushka on 3/3/19.
 */
public class Foundation {
    private int var1;
    int var2;
    protected int var3;
    public int var4;

    public Foundation() {
    }

    public int getVar1() {
        return var1;
    }

    public void setVar1(int var1) {
        this.var1 = var1;
    }



}
