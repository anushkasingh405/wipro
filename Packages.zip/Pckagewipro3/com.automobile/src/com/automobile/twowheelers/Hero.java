package twowheelers;
import com.automobile.*;
/**
 * Created by anushka on 3/3/19.
 */
public class Hero extends Vehicle{

    String Modelname ="Xtreme200R";
    String  registrationnumber="XYTR4321";
    String Ownername="ashish verma";
    int speed=80;

    public String getModelname() {Modelname=Modelname; return Modelname;}

    public String getRegistrationnumber(){return registrationnumber;}

    public String getOwnername(){return Ownername;}
    public int getSpeed(){return speed;}
    public void radio(){System.out.println("playing radio");}
}
