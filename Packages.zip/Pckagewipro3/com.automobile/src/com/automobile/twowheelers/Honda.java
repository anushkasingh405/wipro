package twowheelers;
import com.automobile.*;
/**
 * Created by anushka on 3/3/19.
 */
public class Honda extends Vehicle  {

    String Modelname="Activa5G";
    String  registrationnumber="SDE5678";
    String Ownername="JHANVI KAPOOR";
    int Speed=60;


    public String getModelname() {Modelname=Modelname; return Modelname;}

    public String getRegistrationnumber(){return registrationnumber;}

    public String getOwnername(){return Ownername;}

    public int getSpeed(){return Speed;}
    public void cdplayer(){System.out.println("playing songs");}
}
