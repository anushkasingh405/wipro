package twowheelers;
/**
 * Created by anushka on 3/3/19.
 */
public class Test {
    public static void main(String[] args) {
        Hero hero=new Hero();
        Honda honda=new Honda();
        System.out.println(hero.getModelname());
        System.out.println(hero.getOwnername());
        System.out.println(hero.getRegistrationnumber());
        System.out.println(hero.getSpeed());
        hero.radio();

        System.out.println(honda.getModelname());
        System.out.println(honda.getOwnername());
        System.out.println(honda.getRegistrationnumber());
        System.out.println(honda.getSpeed());
        honda.cdplayer();



    }
}
