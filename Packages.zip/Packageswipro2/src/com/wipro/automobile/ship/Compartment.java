package com.wipro.automobile.ship;
/**
 * Created by anushka on 3/3/19.
 */
public class Compartment {

    int height;
    int width;
    int breadth;

}
