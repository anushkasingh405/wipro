import java.util.Scanner;

/**
 * Created by anushka on 25/3/19.
 */
public class Main {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter 1 to add a country");
        System.out.println("Enter to search a country");
        int choice=sc.nextInt();
        SaveCountryName SCN = new SaveCountryName();
        if(choice==1) {
            System.out.println("Enter the country name");
            String name=sc.next();
            System.out.print(SCN.saveCountryName(name));
        }
        else {
            System.out.println("Enter the country name");
            String name=sc.next();
            System.out.print(SCN.getCountryName(name));
        }
    }
}
