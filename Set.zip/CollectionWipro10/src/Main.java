import java.util.Iterator;
import java.util.TreeSet;

/**
 * Created by anushka on 25/3/19.
 */
public class Main {
    public static void main(String[] args) {
        TreeSet<String> str=new TreeSet<>();
        int flag=0;
        str.add("hii");
        str.add("hello");
        str.add("bonjour");
        str.add("hola");
        Iterator i=str.iterator();
        while (i.hasNext()){System.out.println(i.next());}
        System.out.println(str.descendingSet());
        Iterator itr=str.iterator();
        while (itr.hasNext()){if(((String) itr.next()).equalsIgnoreCase("hii")){flag=1; System.out.println("Exists"); break;}}
        if(flag==0){System.out.println("Doesn't Exists");}

    }
}
