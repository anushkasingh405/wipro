import java.util.HashSet;
import java.util.Iterator;

/**
 * Created by anushka on 25/3/19.
 */
public class Main {
    public static void main(String[] args) {
        HashSet<String> employeeName=new HashSet<>();
        employeeName.add("harish");
        employeeName.add("bhavya");
        employeeName.add("aayushi");
        employeeName.add("deeksha");
        Iterator i= employeeName.iterator();
        while(i.hasNext()){System.out.println(i.next());}
    }
}
