import java.util.HashSet;

/**
 * Created by anushka on 25/3/19.
 */
public class SaveCountryName {
    HashSet<String> H1=new HashSet<>();

    public SaveCountryName() {
        H1.add("India");
    }

    public HashSet saveCountryName(String name)
    {
        H1.add(name);
        return H1;
    }
    public String getCountryName(String name)
    {
        for(String value:H1)
        {
            if(value.equalsIgnoreCase(name)){return value;}
        }
        return "null";
    }
}
