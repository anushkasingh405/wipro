/**
 * Created by anushka on 26/2/19.
 */
public class Books {
    private String name;
    private String author;
    private Double price;
    private int qtyinstock;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public int getQtyinstock() {
        return qtyinstock;
    }

    public void setQtyinstock(int qtyinstock) {
        this.qtyinstock = qtyinstock;
    }

    public Books(String name,String author,Double price,int qtyinstock)
    { setName(name);
       setAuthor(author);
        setPrice(price);
        setQtyinstock(qtyinstock);}

    public static void main(String args[])
    {
        Author a1= new Author("Sydney sheldon","sydney@gmail.com",'F');
        Books b1=new Books("the sky is falling","Sydney sheldon",500.0,50);

        System.out.println(" Name: " +b1.getName()+ "\n Author: "+b1.getAuthor()+ "\n Price: "+b1.getPrice()+ "\n EMail: "+a1.getEmail() + "\n Gender: "+ a1.getGender()+ "\n QTY: "+b1.getQtyinstock());
    }
}
