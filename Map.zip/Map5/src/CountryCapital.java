import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * Created by anushka on 25/3/19.
 */
public class CountryCapital {

    TreeMap<String,String> M1=new TreeMap<>();
    Map.Entry<String,String> m;

    public CountryCapital() {
        M1.put("India","Delhi");
    }

    public TreeMap<String, String> saveCountryCapital(String CountryName, String capital)
    {M1.put(CountryName,capital); return M1;}

    public String getCapital(String CountryName)
    {return  M1.get(CountryName); }

    public String getCountryName(String capital) {
        String getkey="";
        for (Map.Entry<String, String> entry : M1.entrySet()) {
            if (entry.getValue().equals(capital)) {
                 getkey=entry.getKey();
            }

        } return  getkey;
    }

     public HashMap reverseIterate()
    {
        HashMap<String,String> M2=new HashMap<>();
        for (Map.Entry<String, String> entry : M1.entrySet())
        {
            M2.put(entry.getValue(),entry.getKey());
        }
        return  M2;
        }
    }


