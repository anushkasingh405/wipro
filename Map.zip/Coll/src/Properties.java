import java.util.Hashtable;

/**
 * Created by anushka on 27/3/19.
 */
public class Properties {
    Hashtable<String,String> statesCapital=new Hashtable<>();
    public Hashtable Save(String state, String capital)
    {
        statesCapital.put(state, capital);
        return statesCapital;
    }

    public Hashtable<String, String> getStatesCapital() {
        return statesCapital;
    }
}
