import java.util.Iterator;
import java.util.Set;

/**
 * Created by anushka on 27/3/19.
 */
public class Main {
    public static void main(String[] args) {
        Properties properties=new Properties();
        properties.Save("Uttar Pradesh","Lucknow");
        properties.Save("Gujarat","Gandhinagar");
        properties.Save("Biahr","Patna");

        Set set= properties.getStatesCapital().entrySet();
        Iterator itr=set.iterator();
        while (itr.hasNext())
        {System.out.println(itr.next());}
    }
}
