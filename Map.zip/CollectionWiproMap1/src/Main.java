/**
 * Created by anushka on 25/3/19.
 */
public class Main {
    public static void main(String[] args) {

        CountryCapital countryCapital=new CountryCapital();
        String capital=countryCapital.getCapital("India");
        String country=countryCapital.getCountryName("Delhi");
        System.out.println(capital);
        System.out.println(country);
        System.out.println("M1");
        System.out.println(countryCapital.saveCountryCapital("Japan","Tokyo"));
        System.out.println("M2");
        System.out.println(countryCapital.reverseIterate());
    }
}
