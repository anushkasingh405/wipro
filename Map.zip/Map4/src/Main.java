import java.util.Iterator;
import java.util.Set;

/**
 * Created by anushka on 27/3/19.
 */
public class Main {
    public static void main(String[] args) {
        ContactList contactList=new ContactList();
        contactList.saveContactInfo("shweta",54389765);
        contactList.saveContactInfo("Akash",123456879);
        int number=contactList.getphoneNo("Akash");
        String name=contactList.getName(123456879);
        System.out.println(number);
        System.out.println(name);

        Set set= contactList.getContactInfo().entrySet();
        Iterator itr=set.iterator();
        while (itr.hasNext())
        {System.out.println(itr.next());}
    }
}
