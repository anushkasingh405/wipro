import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

/**
 * Created by anushka on 27/3/19.
 */
public class ContactList {
    public Hashtable<String, Integer> getContactInfo() {
        return contactInfo;
    }

    Hashtable<String,Integer> contactInfo=new Hashtable<>();

    public void saveContactInfo(String name, Integer phoneNo)
    {contactInfo.put(name, phoneNo); }

    public Integer getphoneNo(String name)
    {return  contactInfo.get(name); }

    public String getName(Integer phoneNo) {
        String getkey="";
        for (Map.Entry<String, Integer> entry : contactInfo.entrySet()) {
            if (entry.getValue().equals(phoneNo)) {
                getkey=entry.getKey();
            }

        } return  getkey;
    }

}
