import java.util.Iterator;
import java.util.Set;

/**
 * Created by anushka on 25/3/19.
 */
public class Main {
    public static void main(String[] args) {

        StrHashMap strHashMap=new StrHashMap();
        String surname=strHashMap.getValue("Singh");
        String firstname=strHashMap.getKey("Anushka");
        System.out.println(firstname);
        System.out.println(surname);
        System.out.println("M1");
        System.out.println(strHashMap.save());
        Set set= strHashMap.save().entrySet();
        Iterator itr=set.iterator();
        while (itr.hasNext())
        {System.out.println(itr.next());}

    }
}
