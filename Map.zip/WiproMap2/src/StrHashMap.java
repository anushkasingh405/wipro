import java.util.HashMap;
import java.util.Map;

/**
 * Created by anushka on 27/3/19.
 */
public class StrHashMap {

    HashMap<String,String> M1=new HashMap<>();

    public StrHashMap() {
        M1.put("Singh","Anushka");
        M1.put("Singhania","Ayushi");

    }

    public HashMap save()
    { return M1;}

    public String getValue(String key)
    {return  M1.get(key); }

    public String getKey(String value) {
        String getkey="";
        for (Map.Entry<String, String> entry : M1.entrySet()) {
            if (entry.getValue().equals(value)) {
                getkey=entry.getKey();
            }

        } return  getkey;
    }
}
