/**
 * Created by anushka on 2/3/19.
 */
public class Luggage extends Compartment {

    public  String notice()
    {return "Luggage";}
}
