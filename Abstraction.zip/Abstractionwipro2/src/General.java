/**
 * Created by anushka on 2/3/19.
 */
public class General extends Compartment {

    public  String notice()
    {return "General";}

}
