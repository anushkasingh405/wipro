/**
 * Created by anushka on 2/3/19.
 */
public abstract class Compartment {

    public abstract String notice();
}
