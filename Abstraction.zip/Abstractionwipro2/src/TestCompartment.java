import java.util.Random;

/**
 * Created by anushka on 2/3/19.
 */
public class TestCompartment {

    public static void main(String args[])
    {
        Compartment[] compartments=new Compartment[10];
        Random random=new Random();
        int rand=1+random.nextInt(4);
        int i=0;
        System.out.println(rand);

        switch(rand)
        {
            case 1:compartments[i]= new General();
                    System.out.println(compartments[i].notice());
                i++;
                break;

            case 2:compartments[i]= new Ladies();
                System.out.println(compartments[i].notice());
                i++;
                break;

            case 3:compartments[i]=new FirstClass();
                System.out.println(compartments[i].notice());
                i++;
                break;

            case 4:compartments[i]=new Luggage();
                System.out.println(compartments[i].notice());
                i++;
                break;
        }

    }
}
