/**
 * Created by anushka on 2/3/19.
 */
public class FirstClass extends Compartment {

    public  String notice()
    {return "First class";}
}
