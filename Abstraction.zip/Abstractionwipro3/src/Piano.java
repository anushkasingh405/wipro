/**
 * Created by anushka on 2/3/19.
 */
public class Piano extends Instrument {

    public void play(){

        System.out.println("Piano is playin tan tan tan tan");
    }
}
