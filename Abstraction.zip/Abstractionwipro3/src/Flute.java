/**
 * Created by anushka on 2/3/19.
 */
public class Flute extends Instrument {

    public void play(){

        System.out.println("Flute is playin toot toot toot toot");
    }
}
