/**
 * Created by anushka on 2/3/19.
 */
public abstract  class Instrument {

    public abstract void play();
}
