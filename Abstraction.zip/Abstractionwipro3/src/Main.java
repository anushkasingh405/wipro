/**
 * Created by anushka on 2/3/19.
 */
public class Main {
    public static void main(String[] args) {

        int i=0;
        Instrument[] instruments=new Instrument[10];
            instruments[0]=new Flute();
            instruments[1]=new Guitar();
            instruments[2]=new Piano();
            instruments[9]=new Flute();
            instruments[6]=new Guitar();
            instruments[3]=new Piano();
            instruments[7]=new Flute();
            instruments[4]=new Guitar();
            instruments[5]=new Piano();
            instruments[8]=new Guitar();

            for(i=0;i<10;i++)
            {
                if(instruments[i] instanceof Flute)
                {System.out.println("Flute is playing");}

                if(instruments[i] instanceof Piano)
                {System.out.println("Piano is playing");}

                if(instruments[i] instanceof Guitar)
                {System.out.println("Guitar is playing");}
            }
    }
}
