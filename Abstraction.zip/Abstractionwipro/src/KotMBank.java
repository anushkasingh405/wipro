/**
 * Created by anushka on 2/3/19.
 */
public class KotMBank extends GeneralBank {

    int savingsinterestrate;
    int fixedinterestrate;
    public   double  getSavingsInterestRate(){ return 6;}
    public   double  getFixedDepositInterestRate(){return 9;}
}
