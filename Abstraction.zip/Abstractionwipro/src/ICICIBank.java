/**
 * Created by anushka on 2/3/19.
 */
public class ICICIBank extends GeneralBank{

    public   double  getSavingsInterestRate(){ return 4;}
    public   double  getFixedDepositInterestRate(){return 8.5;}
}
