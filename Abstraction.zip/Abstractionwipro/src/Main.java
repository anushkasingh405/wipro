/**
 * Created by anushka on 2/3/19.
 */
public class Main {
    public static  void main(String args[])
    {

        ICICIBank iciciBank=new ICICIBank();
       System.out.println(iciciBank.getSavingsInterestRate());
        System.out.println(iciciBank.getFixedDepositInterestRate());

        KotMBank kotMBank=new KotMBank();
        System.out.println(kotMBank.getSavingsInterestRate());
        System.out.println(kotMBank.getFixedDepositInterestRate());

        GeneralBank ic= new ICICIBank() ;
        GeneralBank k=new KotMBank();

        System.out.println(ic.getSavingsInterestRate());
        System.out.println(ic.getFixedDepositInterestRate());

        System.out.println(k.getSavingsInterestRate());
        System.out.println(k.getFixedDepositInterestRate());



    }
}
