/**
 * Created by anushka on 6/3/19.
 */
public class LibraryInterfaceDemo {

    public static void main(String[] args) {

        System.out.println("For registering enter 1 and for requesing a book enter 2");
        AdultUser adultUser=new AdultUser();
        KidUsers kidUsers=new KidUsers();
        if(Integer.parseInt(args[0])==1)
        {
            System.out.println("Enter age");
            adultUser.setAge(Integer.parseInt(args[1]));
            kidUsers.setAge(Integer.parseInt(args[1]));
            adultUser.registerAccount();
            kidUsers.registerAccount();
        }

        else
            {
                System.out.println("Enter the type of the book");
                adultUser.setBookType(args[1]);
                kidUsers.setBookType(args[1]);
                adultUser.requestBook();
                kidUsers.requestBook();
            }
    }
}
