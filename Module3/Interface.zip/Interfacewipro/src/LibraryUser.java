/**
 * Created by anushka on 6/3/19.
 */
interface LibraryUser {

    void registerAccount();
    void requestBook();
}
