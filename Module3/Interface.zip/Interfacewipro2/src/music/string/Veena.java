package music.string;
import music.Playable;
/**
 * Created by anushka on 6/3/19.
 */
public class Veena implements Playable{

    public void play()
    {System.out.println("Playing Veena");}
}
