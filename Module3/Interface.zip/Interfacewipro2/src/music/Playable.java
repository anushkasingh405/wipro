package music;

/**
 * Created by anushka on 6/3/19.
 */
public interface Playable {
    void play();

}
