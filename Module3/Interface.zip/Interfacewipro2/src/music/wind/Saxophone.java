package music.wind;
import music.Playable;
/**
 * Created by anushka on 6/3/19.
 */
public class Saxophone implements Playable{

    public void play()
    {System.out.println("Playing Saxophone");}
}
