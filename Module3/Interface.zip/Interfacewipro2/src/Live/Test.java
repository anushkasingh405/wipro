package Live;
import music.Playable;
import music.string.Veena;
import music.wind.Saxophone;

/**
 * Created by anushka on 6/3/19.
 */
public class Test {

    public static void main(String[] args) {


       Veena veena=new Veena();
       Saxophone saxophone=new Saxophone();

        veena.play();
        saxophone.play();

        Playable veenaPlayable=veena;
        Playable saxophonePlayable=saxophone;
        veenaPlayable.play();
        saxophonePlayable.play();

    }
}
