/**
 * Created by anushka on 12/3/19.
 */
public class SB extends Account {

    double interestRate;
    double amount;

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(String accountType) {

        if(accountType.equalsIgnoreCase("NORMAL"))
        {this.interestRate=4;}
        else
        {this.interestRate=6;}

    }

    double calculateInterest()
    {
        amount=getAmount();
        interestRate=getInterestRate();

        return (amount*interestRate)/100;
    }


}
