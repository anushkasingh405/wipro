/**
 * Created by anushka on 12/3/19.
 */
public abstract class Account {
    double interestRate;
    double amount;
    abstract double calculateInterest();

}
