/**
 * Created by anushka on 13/3/19.
 */
public class MyException extends Exception{

}
