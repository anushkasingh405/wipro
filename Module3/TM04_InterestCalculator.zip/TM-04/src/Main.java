import java.util.Scanner;

/**
 * Created by anushka on 13/3/19.
 */
public class Main {
    public static void main(String[] args) {

        int option;
        int amount;
        int age;
        int days;

        System.out.println("Interest Calculator -SB");
        System.out.println("Interest Calculator -FD");
        System.out.println("Interest Calculator -RD");
        System.out.println("Exit");
        System.out.println("Enter your option");
        Scanner sc= new Scanner(System.in);
        option=sc.nextInt();

        SB sb = new SB();
        FD fd=new FD();
        RD rd = new RD();

        switch (option)
        {
            case 1:System.out.println("Enter Type of Account NRI or Normal ");
             sb.setInterestRate(sc.next());
                System.out.println("Enter the Average amount in your account:");
                amount=sc.nextInt(); try {if(amount<0) {throw new MyException();}}catch (MyException e){System.out.println("Invalid Number of days. Please enter non-negative values"); break;}
                sb.setAmount(amount);
                System.out.println("Interest Gained : "+ sb.calculateInterest());
                break;

            case 2:System.out.println("Enter the FD Amount:");
                amount=sc.nextInt(); try {if(amount<0) {throw new MyException();}}catch (MyException e){System.out.println("Invalid Number of days. Please enter non-negative values"); break;}
                fd.setAmount(amount);
                    System.out.println("Enter the number of Days:");
                days=sc.nextInt(); try {if(days<0) {throw new MyException();}}catch (MyException e){System.out.println("Invalid Number of days. Please enter non-negative values"); break;}
                fd.setMaturityPeriod(days);
                    System.out.println("Enter your age");
                age=sc.nextInt(); try {if(age<0) {throw new MyException();}}catch (MyException e){System.out.println("Invalid Number of days. Please enter non-negative values"); break;}
                fd.setAgeOfACHolder(age);
                System.out.println("Interest Gained : "+ fd.calculateInterest());
                break;

            case 3:System.out.println("Enter the RD Amount:");
                amount=sc.nextInt(); try {if(amount<0) {throw new MyException();}}catch (MyException e){System.out.println("Invalid Number of days. Please enter non-negative values"); break;}
                rd.setAmount(amount);
                System.out.println("Enter the number of Months:");
                days=sc.nextInt(); try {if(days<0) {throw new MyException();}}catch (MyException e){System.out.println("Invalid Number of days. Please enter non-negative values"); break;}
                rd.setNoOfMonths(days);
                System.out.println("Enter your age");
                age=sc.nextInt(); try {if(age<0) {throw new MyException();}}catch (MyException e){System.out.println("Invalid Number of days. Please enter non-negative values"); break;}
                rd.setAgeOfAccHolder(age);
                System.out.println("Interest Gained : "+ rd.calculateInterest());
                break;

            case 4:
                break;

        }

    }
}
