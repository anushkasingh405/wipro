/**
 * Created by anushka on 12/3/19.
 */
public class FD extends Account {
    double interestRate;
    int maturityPeriod; ///noOfDays
    int ageOfACHolder;
    int amount;

    public int getMaturityPeriod() {
        return maturityPeriod;
    }

    public void setMaturityPeriod(int maturityPeriod) {
        this.maturityPeriod = maturityPeriod;
    }

    public int getAgeOfACHolder() {
        return ageOfACHolder;
    }

    public void setAgeOfACHolder(int ageOfACHolder) {
        this.ageOfACHolder = ageOfACHolder;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    double calculateInterest()
    {
        maturityPeriod=getMaturityPeriod();
        ageOfACHolder=getAgeOfACHolder();
        amount=getAmount();

        if (amount<10000000)
        {
           if(maturityPeriod>6 &maturityPeriod<15){interestRate=4.5;}
            if(maturityPeriod>14& maturityPeriod<30){interestRate=4.75;}
            if(maturityPeriod>29& maturityPeriod<46){interestRate=5.50;}
            if(maturityPeriod>44& maturityPeriod<61){interestRate=7;}
            if(maturityPeriod>60& maturityPeriod<185){interestRate=7.5;}
            if(maturityPeriod>185 & maturityPeriod<367){interestRate=8;}
            if (ageOfACHolder>59)
            {interestRate=interestRate+0.50; }

        }

        else
        {
            if(maturityPeriod>6 & maturityPeriod<15){interestRate=6.5;}
            if(maturityPeriod>14 & maturityPeriod<30){interestRate=6.75;}
            if(maturityPeriod>2 & maturityPeriod<46){interestRate=6.75;}
            if(maturityPeriod>44 & maturityPeriod<61){interestRate=8;}
            if(maturityPeriod>60 & maturityPeriod<185){interestRate=8.50;}
            if(maturityPeriod>185 & maturityPeriod<367){interestRate=10;}

        }

        return (amount*interestRate)/100;
    }

}
