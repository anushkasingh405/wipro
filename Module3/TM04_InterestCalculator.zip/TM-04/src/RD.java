/**
 * Created by anushka on 12/3/19.
 */
public class RD extends Account {
    double interestRate;
    int noOfMonths;
    int ageOfAccHolder;
    double amount;

    public int getNoOfMonths() {
        return noOfMonths;
    }

    public void setNoOfMonths(int noOfMonths) {
        this.noOfMonths = noOfMonths;
    }

    public int getAgeOfAccHolder() {
        return ageOfAccHolder;
    }

    public void setAgeOfAccHolder(int ageOfAccHolder) {
        this.ageOfAccHolder = ageOfAccHolder;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double monthlyAmount) {
        this.amount = monthlyAmount;
    }

    double calculateInterest(){

        amount=getAmount();
        ageOfAccHolder=getAgeOfAccHolder();
        noOfMonths=getNoOfMonths();

        switch (noOfMonths)
        {
            case 6: interestRate=7.50;
            break;

            case 9: interestRate=7.75;
            break;

            case 12: interestRate=8;
            break;

            case 15: interestRate=8.25;
            break;

            case 18:interestRate=8.50;
            break;

            case 21:interestRate=8.75;
            break;
        }
        if (ageOfAccHolder>59)
        {interestRate=interestRate +0.50;}

       return (amount*interestRate)/100; }
}
