import java.util.Scanner;

/**
 * Created by anushka on 9/3/19.
 */
public class Division {

    public static void main(String[] args)  {

        Scanner sc = new Scanner(System.in);
        try {
            System.out.println("Enter the 2 numbers");
            int a = sc.nextInt();
            int b = sc.nextInt();
            int c = a / b;
            System.out.println("THe quotient of "+ a +"/"+b+" = "+c);
        } catch (ArithmeticException e)
        { System.out.println(e.getMessage());}
        finally {
            System.out.println("Inside finally block");
        }
    }
}
