import java.util.Scanner;

/**
 * Created by anushka on 9/3/19.
 */
public class Main {

    public static void main(String[] args) {
        int age;
        String name;
        Scanner sc = new Scanner(System.in);
        System.out.println("enter name and age");
        try {
            name = sc.next();
            age = sc.nextInt();
            if (age < 17 || age > 60) {
                throw new MyException();
            } else { System.out.println("Valid user");
            }
        }catch (MyException e){System.out.println("Error message");}

    }
}
