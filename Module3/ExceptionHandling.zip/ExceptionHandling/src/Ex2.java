import java.util.Scanner;

/**
 * Created by anushka on 8/3/19.
 */
public class Ex2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String string = sc.nextLine();
        System.out.println("Enter an integer");
        try {
            int number = Integer.parseInt(string);
            System.out.println(number * number);
            System.out.println("The work has been done successfully");

        } catch (NumberFormatException e) {
            System.out.println("Entered input is not a valid format for an integer");
        }


    }}