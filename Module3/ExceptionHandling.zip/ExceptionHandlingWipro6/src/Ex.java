import java.util.Scanner;

/**
 * Created by anushka on 8/3/19.
 */
public class Ex {

    public static void main(String[] args) {

        System.out.println("Enter the name of the student and marks of Physics, chemistry and mathematics");
        Scanner sc = new Scanner(System.in);
        try {
            String name = sc.next();
            int physics = sc.nextInt();
            int Chemistry = sc.nextInt();
            int mathematics = sc.nextInt();
            int average = (physics + Chemistry + mathematics) / 3;
            if(0< physics & physics <100 & 0< Chemistry & Chemistry <100 & 0< mathematics & mathematics <100)
            { System.out.println(average);}
            else{throw  new ArithmeticException("Throwing ArithmeticException");}
        }
        catch (NumberFormatException e)
        {throw new NumberFormatException("Throwing NumberFormatException");}


    }
}
