import java.util.Scanner;

/**
 * Created by anushka on 8/3/19.
 */
public class Division {

    public static void main(String[] args) throws  ArithmeticException {
        System.out.println("Enter two values");
        Scanner sc = new Scanner(System.in);
        try {
            int a = sc.nextInt();
            int b = sc.nextInt();
            int c = a / b;
        } catch (ArithmeticException e)
        { System.out.println(e.getMessage());}
    }
}
