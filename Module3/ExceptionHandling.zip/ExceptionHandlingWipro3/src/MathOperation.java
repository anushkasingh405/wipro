import java.util.Scanner;

/**
 * Created by anushka on 8/3/19.
 *
 * question 2 n three were same so this is 4
 */
public class MathOperation {
    public static void main(String[] args) throws ArithmeticException,NumberFormatException {

        Scanner sc = new Scanner(System.in);
            int i;
        int average=0;
        int sum=0;
            int array[] = new int[5];
            System.out.println("Enter the elements in the array");

            for (i = 0; i < 5; i++) {
                int value = sc.nextInt();
                array[i] = value;
                sum=sum+array[i];
                average=sum/5;
            }
        System.out.println(sum);
        System.out.println(average);

    }
    }

