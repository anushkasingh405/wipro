import java.util.Scanner;

/**
 * Created by anushka on 8/3/19.
 */
public class Register {

    public static void main(String[] args) {
        UserRegistration userRegistration=new UserRegistration();
        Scanner sc =new Scanner(System.in);
        System.out.println("Enter name and country");
        String name=sc.next();
        String country =sc.next();
        userRegistration.RegisterUser(name,country);

    }
}
