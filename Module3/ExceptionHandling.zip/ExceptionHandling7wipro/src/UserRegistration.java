/**
 * Created by anushka on 8/3/19.
 */
public class UserRegistration {


    void  RegisterUser(String username,String userCountry)  {

        try {
            if (!userCountry.equalsIgnoreCase("India")) {
                throw new InvalidCountryException();
            }
            else System.out.println("User registered successfully");
        }catch (InvalidCountryException e){System.out.println("user outside India cannot be registered");}
        }

    }

