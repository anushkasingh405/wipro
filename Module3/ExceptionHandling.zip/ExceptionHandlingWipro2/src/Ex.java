import java.util.Scanner;

/**
 * Created by anushka on 8/3/19.
 */
public class Ex {
    public static void main(String[] args) {

    try {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of elements in the array");
        int length = sc.nextInt();
        int i;
        int array[] = new int[length];
        System.out.println("Enter the elements in the array");
        for (i = 0; i < length; i++) {
            int value = sc.nextInt();
            array[i] = value;
        }
        System.out.println("Enter the index of the array element you want to access");
        int index = sc.nextInt();
        System.out.println("The elements at the index " + index + " = " + array[index]);
        System.out.println("The array element accessed successfully");

    } catch (ArrayIndexOutOfBoundsException e)
    { System.out.println(ArrayIndexOutOfBoundsException.class.getName());}

    }
}
