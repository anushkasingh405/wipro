
public class Demo2 {
	public boolean palindromeCheck(String str) {
		int i = 0;
		int back = str.length() - 1;
		for (i = 0; i < str.length() / 2; i++) {
			if (str.charAt(i) != str.charAt(back)) {
				return false;
			}
			back--;
		}
		if (str.length() == 0) {
			return false;
		} else {
			return true;
		}
	}
}
