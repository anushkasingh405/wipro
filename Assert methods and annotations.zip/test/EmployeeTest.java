import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class EmployeeTest {
	
	static Employee emp = null;
	static ArrayList<String> list = new ArrayList<String>();


	
	@BeforeClass
	public static void setup(){
		emp = new Employee();
		list.add("Aman");
		list.add("Anuj");
		list.add("Amar");
		list.add("Anik");
	}

	@Test
	public void testForNameFound() {
		assertEquals("FOUND",emp.findName(list, "Aman"));
	}

}
