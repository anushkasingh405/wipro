import java.util.Scanner;

/**
 * Created by anushka on 18/3/19.
 */
public class Main {
    public static void main(String[] args) {

        Scanner sc =new Scanner(System.in);

        int number =sc.nextInt();
        String binary = Integer.toBinaryString(number);
        String result="";
        if(binary.length()<8)
        {
            while (result.length() != (8- binary.length()))
            {
                result=result+"0";
            }

        }
        result=result.concat(binary);
        System.out.println(result);
    }
}
