/**
 * Created by anushka on 18/3/19.
 */
public class Main {

    public static void main(String[] args) {
        Employee e1  =new Employee("Devna","19300ITBNG");
        Employee e2 ;
        e2= e1.cloneTest();
        System.out.println(e1.getEmployeeName()+"\n" +e1.getEmployeeID());
        System.out.println(e2.getEmployeeName()+"\n" +e2.getEmployeeID());

        e1.employeeID="18290HRCHN";
        e1.employeeName="Sam";

        System.out.println(e1.getEmployeeName()+"\n" +e1.getEmployeeID());
        System.out.println(e2.getEmployeeName()+"\n" +e2.getEmployeeID());

    }
}
