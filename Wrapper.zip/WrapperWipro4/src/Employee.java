/**
 * Created by anushka on 18/3/19.
 */
public class Employee  implements  Cloneable{
        String employeeName;
        String employeeID;

    Employee cloneTest() {
        try {
            return (Employee) super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        return this;
    }

    public Employee(String employeeName, String employeeID) {
        this.employeeName = employeeName;
        this.employeeID = employeeID;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public String getEmployeeID() {
        return employeeID;
    }
}
