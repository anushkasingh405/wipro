/**
 * Created by anushka on 18/3/19.
 */
public class Main {
    public static void main(String[] args) {
        int number  = Integer.parseInt(args[0]);
        String binary = Integer.toBinaryString(number);
        String octal = Integer.toOctalString(number);
        String hexadecimal = Integer.toHexString(number);

        System.out.println("Given number:" +number);
        System.out.println("Binary Equivalent:"+binary);
        System.out.println("Octal Equivalent:" +octal);
        System.out.println("Hexadecimal Equivalent:" +hexadecimal);

    }
}
