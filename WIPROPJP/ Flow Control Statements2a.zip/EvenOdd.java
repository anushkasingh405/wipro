public class EvenOdd{
    public static void main(String args[])
      {
        int value= Integer.parseInt(args[0]);
         if(value%2 == 0)
          {System.out.println("Even");}

         else 
          {System.out.println("Odd");}
      }
}
