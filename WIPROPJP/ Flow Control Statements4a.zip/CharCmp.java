public class CharCmp{
    public static void main(String args[])
      {
        char a='x';
        char b='t';

        if(a > b)
        {System.out.println(b +"," + a);}
        else 
         {System.out.println(a +"," + b);}
         
      }
}
