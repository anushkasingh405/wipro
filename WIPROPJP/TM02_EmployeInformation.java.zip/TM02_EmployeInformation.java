public class TM02_EmployeInformation
{
	public static void main(String args[])
	{  String Desig="";
           int index;
	   int salary;
	   int DAval=0;
	   int[] EmpNo={1001 ,1002,1003,1004,1005,1006,1007};
	   String[] EmpName={"Ashish","Sushma","Rahul" ,"Chahat" ,"Ranjan","Suman","Tanmay"};
	   String[] Department={"R&D","PM","Acct","Front Desk","Engg","Manufacturing","PM"};
	   String[] Designation={"e","c","k","r","m","e","c"};
	   int[] Basic={20000,30000,10000,12000,50000,23000,29000};
           int[] HRA={8000,12000,8000,6000,20000,9000,12000};
	   int[] IT={3000,9000,1000,2000,20000,4400,10000};
	   int[] DA={20000,32000,12000,15000,40000};
	   String[] date={"01/04/2009","23/08/2012","12/11/2008"," 29/01/2013"," 16/07/2005", "1/1/2000", "12/06/2006"};

		index=Integer.parseInt(args[0]);
		
	     if(index >1000&&index<1008)
	     {  index=(index%10)-1;
	       switch(Designation[index])
	       {
		case "e":Desig="Engineer"; DAval=DA[0];
			break;
		case "c":Desig="Consultant"; DAval=DA[1];
			break;
		case "k":Desig="Clerk"; DAval=DA[2];
		break;
		case "r":Desig="Receptionist"; DAval=DA[3];
			break;
		case "m":Desig="Manager";  DAval=DA[4];
			break;
	       }	
          

		salary=Basic[index]+HRA[index]+DAval-IT[index];
		System.out.println("EmpNo"+"  "+"EmpName"+"  "+"Department"+"  "+"Designation"+"  "+"Salary");
		System.out.println(EmpNo[index]+"    "+EmpName[index]+"    "+Department[index]+"       "+Desig+"       "+salary);
	     }
	     else{System.out.println("There is no employee with Empid: "+ args[0]);}
	}
}
