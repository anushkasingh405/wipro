import java.sql.*;
import java.util.Scanner;

/**
 * Created by anushka on 14/5/19.
 */
public class Main {
    public static void main(String[] args) throws ClassNotFoundException {
        String query="";
        switch (Integer.parseInt(args[0])) {
            case 1:query = Insert.insert(Integer.parseInt(args[1]),args[2],args[3],args[4],Integer.parseInt(args[5])); break;
            case 2:query=Delete.delete(Integer.parseInt(args[1])); break;
            case 3:query=Modify.modify(Integer.parseInt(args[1])); break;
            case 4: if(args.length==1) {query=Display.display(0);} else{query=Display.display(Integer.parseInt(args[1]));}
            default:
                System.out.println("Choose a value from the above options");}

                String hostname = "HR";
                String password = "anu";
                Connection con = null;

                try {
                    Class.forName("oracle.jdbc.driver.OracleDriver");
                    con = DriverManager.getConnection(
                            "jdbc:oracle:thin:@localhost:1521/XE", hostname, password);
                    Statement stmt = con.createStatement();
                    ResultSet rs = stmt.executeQuery(query);
                    while (rs.next()) {
                        System.out.println(rs.getInt(1) + " " + rs.getString(2));
                    }
                    con.close();

                } catch (SQLException e) {
                    e.printStackTrace();
                }

        }
    }

