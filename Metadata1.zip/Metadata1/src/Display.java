/**
 * Created by anushka on 14/5/19.
 */
public class Display {
    public static String display(int rollno)
    {
        String statement;
        if(rollno==0)
            {statement="select * from student";}
       else { statement="select * from student where rollno="+rollno+"";}
        return statement;
    }
}
