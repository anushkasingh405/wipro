import java.util.Scanner;

/**
 * Created by anushka on 14/5/19.
 */
public class Modify {

    public static String modify(int fee)
    {
        String statement;

        statement="delete from student where fee="+fee+"";
        return statement;
    }
}
