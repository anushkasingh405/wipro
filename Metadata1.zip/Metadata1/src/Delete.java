import java.util.Scanner;

/**
 * Created by anushka on 14/5/19.
 */
public class Delete {
    public static String delete(int rollno)
    {
        String statement;
        statement="delete from student where rollno="+rollno+"";
        return statement;
    }
}
