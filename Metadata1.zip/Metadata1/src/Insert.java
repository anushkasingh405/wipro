import java.util.Scanner;

/**
 * Created by anushka on 14/5/19.
 */
public class Insert {
    public static String insert(int rollno, String name,String standard,String date,int fee)
    {
        String statement;

        statement="insert into student values("+rollno+","+name +","+standard+","+date+","+fee+")";
        return statement;
    }
}
