import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

/**
 * Created by anushka on 25/3/19.
 */
public class Main {
    public static void main(String[] args) {
        ArrayList<String> Str= new ArrayList<>();
        Str.add("hiii");
        Str.add("I");
        Str.add("am");
        Str.add("Flora");

    printall(Str);

    }

   public static void printall(Collection<String> s)
    {for (String x:s)
        System.out.println(s);
    }
}
