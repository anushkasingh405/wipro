import java.util.ArrayList;

/**
 * Created by anushka on 25/3/19.
 */
public class EmployeeDB {


    public ArrayList getList() {
        return list;
    }

    ArrayList list=new ArrayList();
    boolean addEmployee(Employee e){ boolean result=list.add(e); return result;}
    boolean deleteEmployee(int empId){list.remove(empId); return true;}

   String showPaySlip(int empId){
       Employee getsal=(Employee) list.get(empId);
        return Float.toString(getsal.salary);}


}
