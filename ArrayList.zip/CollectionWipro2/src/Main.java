/**
 * Created by anushka on 25/3/19.
 */
public class Main {
    public static EmployeeDB employeeDB= new EmployeeDB();
    public static void main(String[] args) {

        Employee e=new Employee(0,"sachin","Sachin@gmail.com","Male",30000f);
        boolean result=employeeDB.addEmployee(e);
        System.out.println("Adding sachin into the list:"+result);
        System.out.println( "Salary of employee:"+employeeDB.showPaySlip(0));


        Employee e1=new Employee(1,"riya","riya@gmail.com","Female",50000f);
        boolean result1=employeeDB.addEmployee(e1);
        System.out.println("Adding riya into the list:"+result1);
        System.out.println("Details  Employee");
        e.getEmployeeDetails();

        boolean result2=employeeDB.deleteEmployee(0);
        System.out.println("Deleting sachin from the list:"+result2);
       System.out.println( "Salary of employee after deleting empId 0: "+employeeDB.showPaySlip(0));
        System.out.println("Details of Employee after deletion");
        e.getEmployeeDetails();
    }
}
