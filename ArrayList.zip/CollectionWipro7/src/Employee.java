import java.util.ArrayList;
import java.util.Vector;

/**
 * Created by anushka on 25/3/19.
 */
public class Employee {

    int empId;
    String empName;
    String email;
    String gender;
    Float salary;

    public Employee(int empId, String empName, String email, String gender, Float salary) {
        this.empId = empId;
        this.empName = empName;
        this.email = email;
        this.gender = gender;
        this.salary = salary;

    }

  void getEmployeeDetails()
    {
        Vector empDetails=Main.employeeDB.getList();
        for(Object o:empDetails)
        { Employee details= (Employee) o; System.out.println(details.empId+ "\n" +details.empName+ "\n" +details.salary+ "\n" +details.email+ "\n" +details.gender);}
    }
}
