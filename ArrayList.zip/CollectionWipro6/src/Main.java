import java.util.Vector;

/**
 * Created by anushka on 25/3/19.
 */
public class Main {
    public static void main(String[] args) {
        Vector<String> Months=new Vector<>();
        Months.add("January");
        Months.add("February");
        Months.add("March");
        Months.add("April");
        Months.add("May");
        Months.add("June");
        Months.add("July");
        Months.add("August");
        Months.add("September");
        Months.add("October");
        Months.add("November");
        Months.add("December");
        for(String str:Months){System.out.println(str);}
    }
}
