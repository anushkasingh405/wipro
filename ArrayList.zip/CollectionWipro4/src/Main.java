import java.util.ArrayList;

/**
 * Created by anushka on 25/3/19.
 */
public class Main {
    public static void main(String[] args) {
        ArrayList<Number> numbers=new ArrayList<>();
        numbers.add(10);
        numbers.add(35.5f);
        numbers.add(35.50);
        System.out.println(numbers);
    }
}
