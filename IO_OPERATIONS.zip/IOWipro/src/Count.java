import java.io.*;
import java.util.Scanner;

/**
 * Created by anushka on 19/3/19.
 */
public class Count {
    public static void main(String[] args) throws IOException{
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the name of the file");
        String link=sc.next();
        File inputFile= new File(link);
        FileReader in= new FileReader(inputFile);
        System.out.println("Enter any character");
        String character=sc.next();
        int c;
        int count=0;
        while ((c=in.read())!=-1)
        {
            if((int)character.charAt(0)==c ||(int)character.charAt(0)==c+32 ||(int)character.charAt(0)==c-32){count=count+1;}

        }
        System.out.println(count);
    }
}
