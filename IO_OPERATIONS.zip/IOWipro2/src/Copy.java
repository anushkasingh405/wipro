import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 * Created by anushka on 19/3/19.
 */
public class Copy {
    public static void main(String[] args)  throws IOException
    {
        System.out.println("Enter the name of the file");
        Scanner sc = new Scanner(System.in);
        String link=sc.next();
        File file=new File(link);
        FileReader fileReader= new FileReader(file);
        File file1= new File("output.txt");
        FileWriter fileWriter=new FileWriter(file1);
        int c ;
        while((c=fileReader.read()) != -1)
        {fileWriter.write( c);}
        fileWriter.close();
        System.out.println("File is copied");
    }
}
