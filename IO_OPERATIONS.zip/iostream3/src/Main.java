import java.io.*;
import java.util.*;

/**
 * Created by anushka on 16/4/19.
 */
public class Main {
    public static void main(String[] args)  throws IOException
    { int c ;

        System.out.println("Enter the name of the file");
        Scanner sc = new Scanner(System.in);
        String link=sc.next();
        BufferedReader objReader = new BufferedReader(new FileReader(link));
        Mapping mapping=new Mapping();
        String str="";
        while((str= objReader.readLine()) != null)

        {
            int i=0;
            String array[]=str.split(" ");
            while (array.length != i) {
                mapping.savewordcount(array[i], 0); i++;
            }
        }
        mapping.filewriter();
    }
}
///home/anushka/Source.txt