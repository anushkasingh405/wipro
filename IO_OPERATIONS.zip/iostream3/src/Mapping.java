import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.*;

/**
 * Created by anushka on 16/4/19.
 */
public class Mapping {
    HashMap<String,Integer> wordcount= new HashMap<>();
    ArrayList arrayList=new ArrayList();
    public void savewordcount(String key, int value)
    {
      if(wordcount.containsKey(key))
      {wordcount.put(key,(wordcount.get(key)+1));
      }

      else{
          wordcount.put(key,1); arrayList.add(key);
      }
    }


    public void filewriter() throws IOException {

        Set<Map.Entry<String, Integer>> set = wordcount.entrySet();
        for (Map.Entry<String, Integer> entry : set)
        {
            BufferedWriter objWriter= new BufferedWriter(new FileWriter("output.txt"));
            objWriter.write(entry.getKey()+":"+entry.getValue());
            System.out.println(entry.getKey()+":"+entry.getValue());
        }
    }
}
