/**
 * Created by anushka on 27/2/19.
 */
public class Employee extends Person {

    String name;
    double salary;
    int beginingyear;
    String nin;

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public int getBeginingyear() {
        return beginingyear;
    }

    public void setBeginingyear(int beginingyear) {
        this.beginingyear = beginingyear;
    }

    public String getNin() {
        return nin;
    }

    public void setNin(String nin) {
        this.nin = nin;
    }
}
