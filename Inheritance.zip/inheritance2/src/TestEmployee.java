/**
 * Created by anushka on 27/2/19.
 */
public class TestEmployee {

    public static void main(String args[]){

        Employee e1= new Employee();
        Person p1 = new Person();
        p1.setName("Akash");
        e1.setName(p1.getName());
        e1.setNin("ISN34532");
        e1.setSalary(500000);
        e1.setBeginingyear(2017);

        System.out.println(e1.getName()+"\n"+e1.getBeginingyear()+"\n"+e1.getSalary()+"\n"+e1.getNin());
    }
}
