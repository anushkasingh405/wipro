/**
 * Created by anushka on 27/2/19.
 */
public class Main {

    public static void main(String args[]) {
        Animal a1=new Animal();
        a1.eat();
        a1.sleep();
        Animal a2=new Bird();

        a2.sleep();
        a2.eat();
        Bird a3= new Bird();
        a3.fly();
    }
}
