/**
 * Created by anushka on 27/2/19.
 */
public class Animal {

    public void eat() {
        System.out.println("the animal is eating");
    }

    public void sleep() {
        System.out.println("the animal is sleeping");
    }



}

