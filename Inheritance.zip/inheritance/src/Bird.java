/**
 * Created by anushka on 27/2/19.
 */
public class Bird extends Animal {

    public void eat()
    {
        System.out.println("the bird is eating");
    }
    public void sleep()
    {
        System.out.println("the bird is sleeping");
    }
    public void fly()
    {
        System.out.println("the bird is flying");
    }
}
