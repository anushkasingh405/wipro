/**
 * Created by anushka on 4/3/19.
 */
public class Test {

    public static void main(String[] args) {

        Person person =new Person("Shivam","20-02-1998");
        Person person2 =new Person("Kumar", "13-04-1996");
        Student Student=new Student(person.name,person.dateOfBirth,"1429010036");
        Teacher teacher = new Teacher(person2.name, person2.dateOfBirth,60000,"Physics");
        //Student student=new Student();
        CollegeStudent collegeStudent=new CollegeStudent(Student.name,Student.dateOfBirth,"1429010036","ABESIT",2014);
        System.out.println(" Teacher's Name: "+teacher.name + "Teacher's D.O.B: "+teacher.dateOfBirth +" Subject: "+ teacher.subject+" Salary: "+teacher.salary);
        System.out.println("Student's Name:" +collegeStudent.name +" Student's D.O.B "+ collegeStudent.dateOfBirth+" StudentID: "+ collegeStudent.studentID +" CollegeNmae: "+ collegeStudent.collegeName+" Year: "+ collegeStudent.year);
    }
}
