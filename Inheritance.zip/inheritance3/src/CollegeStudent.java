/**
 * Created by anushka on 27/2/19.
 */
public class CollegeStudent extends Student {

    String collegeName;
    int year;
    String name;
    String studentID;
    String dateOfBirth;

    public CollegeStudent(String name, String dateOfBirth, String studentID, String collegeName, int year) {
        super(name, dateOfBirth, studentID);
        this.collegeName = collegeName;
        this.year = year;
        this.name = name;
        this.studentID = studentID;
        this.dateOfBirth = dateOfBirth;
    }
}
